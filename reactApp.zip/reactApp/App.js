import React, { Component } from 'react';
class App extends Component{

contructor(props) {
  super(props)
 
  this.state = {

   items:[];
   isLoaded : false;
}

componentDidMount() {

fectch('http://api/nytimes.com/svc/mostpopular/v2)
.then (res=>res.json())
.then (json=> {
    this.setState({ isLoaded : true; items.json;})

});

render() {
return (
var {isLoade, items} = this.state;

if (!isLoaded) {
return
<div> Loading </div>
}
else
{
 return (
<div> 
<ul> 
  {items.map(items=>

   <li  key= {items.id}>
      title:{item.title} | Name: {item.name} | Date: {item.date}
     
   </li>
)};

</ul>
</div>

);
}
}


   render(){
      return(
         <div>
            <h1>Welcome Hello</h1>
         </div>
      );
   }
}
export default App;